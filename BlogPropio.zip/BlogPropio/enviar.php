<?php
//$Conexion es la variable donde se almacena la conexion
$conexion = mysql_connect("localhost", "root", "") 
or die ("Fallo en el establecimiento de la conexión");

mysql_select_db("blog",$conexion)
or die("Error en la selección de la base de datos");



$insert= mysql_query("insert into chat (username,destinatario,fecha,asunto,mensaje) values
	('$_REQUEST[usuario]','$_REQUEST[destinatario]','$_REQUEST[fecha]','$_REQUEST[asunto]','$_REQUEST[mensaje]')",$conexion) or die ("problemas en el select".mysql_error());
//cuidado al utilizar el caracter "-" o la palabra "password", no lo guarda en la base de datos, posible palabra reservada?
if(!$insert){
	echo "Error al guardar datos";
}else{
	echo "Datos Guardados";
}



//Cerramos la conexión



mysql_close($conexion);

header("Location:".$_SERVER['HTTP_REFERER']);  

?>