<!DOCTYPE html>
<html lang="es">

<head>
    
    <meta charset="utf-8">
    <title Foro CSCW></title>
    
    <link href="CSS/blog.css" rel="stylesheet">
    <link href="CSS/bootstrap.css" rel="stylesheet">
    
    <script src="JS/bootstrap.js"></script>
          <script src="JS/jquery.js"></script>
          <script src="JS/jquery.flexslider.js"></script>
            <script src="JS/javascript.js"></script>
        <script src="JS/bootstrap-modal.js"></script>
</head>

    <body>
    
         <!-- BARRA DE NAVEGACION 
           <nav class="navbar navbar-inverse navbar-fixed-top">
               <div class="container">
                <div class="navbar-header">
                <a class="navbar-brand" align=left >CS-Blog-CW!</a>
                   </div>
                   <div id="navbar" class="collapse navbar-collapse">
                       
                       <!--Parte izquierda de Navbar -->
                   <ul class="nav navbar-nav">
                        <li ><a href="index.php">Home</a></li>
                        
                       <li class="active"><a data-toggle="modal" data-target="#ModalContact">Mi Perfil</a></li>
                       <li><a href="#"></a></li>
        
                   </ul>
                       
                       <!--Parte derecha de Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <li><a><button  type="button" class="btn btn-danger" data-toggle="modal" data-target="#myModal" >Volver a CSCW</button></a>
  
                        </li>
                       
                       
                       </ul>
                
                </div>
                </div>
               
               
            
        </nav>
        <!- FIN BARRA DE NAVEGACION -->
         <form action="../blogcscw/login.php" method="post" id="login">
          <input type="submit" value="ingresar al blog"/>
        </form>
    </body>
</html>