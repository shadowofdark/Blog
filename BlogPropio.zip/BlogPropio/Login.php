<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Login</title>
<meta name="Autor" content="Daniela Garro y Elio Togno"/>
<meta name="Key" content="Registro"/>
<link href="css/Style.css" rel="stylesheet" type="text/css"/>
</head>
<body>
    
<form class="box" name="form1" method="post" action="Iniciar.php">
<legend>Ingrese sus datos del Blog</legend>
  
	<input type="text" placeholder="nombre de usuario" name="username">
	<input type="password" placeholder="Contraseña" name="password">
	<input type="submit" value="Iniciar Sesion">
	

    <div class="credits">Diseñado por Daniela Garro y Elio Togno</div>
  </form> 

<form method="post" action="registrarse.html">
<input type="submit" value="Registrarse">
</form>
</body>
</html>