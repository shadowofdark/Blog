function mostrar(){
document.getElementById('dashboard').style.display = 'block';
document.getElementById('mensaje').style.display = 'none';
document.getElementById('listarDocumentos').style.display = 'none';
}



function mostrarMsj(){
document.getElementById('mensaje').style.display = 'block';
document.getElementById('dashboard').style.display = 'none';
document.getElementById('listarDocumentos').style.display = 'none';
}



function mostrarDocumentos(){
document.getElementById('listarDocumentos').style.display = 'block';
document.getElementById('mensaje').style.display = 'none';
document.getElementById('dashboard').style.display = 'none';
}
