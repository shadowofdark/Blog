function sacarProp(idPropiedad){

    var id = idPropiedad;
    location.href='mostrarPropiedad.php?variable='+id;
}