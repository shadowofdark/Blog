<?php
$conexion=mysql_connect("localhost","root","1234") 
  or  die("Problemas en la conexion");

mysql_select_db("wordpress",$conexion) 
  or  die("Problemas en la selección de la base de datos");



	$user= $_POST['username'];
	$pass= $_POST['password'];
    $estado = 1;

	$b_user=mysql_query("SELECT * FROM wp_users WHERE user_login='$user'");
	$ses = mysql_fetch_assoc($b_user);

	if(mysql_num_rows($b_user)){
	
		if($ses['password']==$pass){
			 
            
            session_name('data');
			session_start();
			
           
             
             $update= mysql_query("UPDATE wp_users SET 	user_status='$estado' WHERE user_login='$user'",$conexion);
            
            $_SESSION['user_login']=$user;
            $_SESSION['user_status']= $estado;
            $_SESSION['user_nicename']= $nombre;
            
            
			header('Location: index.php');
		}else{
			echo 'Nombre de ususario/Clave incorrecta';
		}
	}else{
		echo 'Nombre de usuario/clave incorrecta';
	}
	


?> 