<?php 

session_name('data');
       session_start();
    

$conexion = mysql_connect("localhost","root","") 
                    or  die("Problemas en la conexion");

mysql_select_db("blog", $conexion) 
                    or  die("Problemas en la selección de la base de datos");

     $usuario = $_SESSION['username'];
    $estado=0;
     session_destroy();
       
        $update= mysql_query("UPDATE usuario SET estado='$estado' WHERE username='$usuario'",$conexion);
       
       //echo "Has cerrado la sesion";
header('Location: login.php');
       
   
?>